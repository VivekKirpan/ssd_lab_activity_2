1. For q1.sh run the command by passing filename as parameter to it. It will output the middle line from the file.
Eg: bash q1.sh file1.txt

2. For q2.sh just run the command to print the names of all shells belonging to '/usr'
Eg: bash q2.sh